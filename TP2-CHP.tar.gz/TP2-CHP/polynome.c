#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>

void polynome(int x,int y,int a[],int l[],int k[],int n) 
 {
int P[n];
int i;
int sum = 0;
# pragma omp parallel for
    for (i = 0; i < n; i++)
     {
           k[i]=pow(x,k[i]);   }  // remarque MJ : l'opération ^ est le ou exclusif au niveau de bits ! et pas la puissance !!
# pragma omp parallel for
    for (i = 0; i < n; i++)
     {
           l[i]=pow(y,l[i]);   } // idem plus haut ! 


# pragma omp parallel for
    for (i = 0; i < n; i++)
     {
           P[i]=a[i]*k[i]*l[i];   }

# pragma omp parallel for reduction(+:sum)
    for (i = 0; i < n; i++)
     {     sum += P[i];

                           }
printf("sum : %d\n",sum);
}



int main(int argc, char* argv[])
{
    int k[4];
    int l[4];
    int a[4];
    int n = 4; // Soyez plus généreux en espace mémoire et aussi déterminer n lors de la lecture du fichie
    int x,y;
    int i = 0;
    char filename[] = "polynome.txt";
    int  IntLine[2] ;
    FILE *fp;
    int *p1,*p2,*p3;

    p1=a;p2=k;p3=l;
/* on definir l,k,a coff de polynome,n est le nombre de chaquede coff ,et IntLine est le nombre de  chaque linge de fichier txt
*/   
     
/* on determine n et on alloue la mémoire pour le coff de a,k,l */

if((fp = fopen(filename,"r")) == NULL){
    printf("the file dont exist!");
    exit(1);
}

  for (int i=0;i<4;i++)
{
    fscanf(fp,"%d%d%d",&a[i], &k[i], &l[i]); // modif MJ  les patrons de lecture ne doivent rien contenir ! 
    printf("a[%d]=%d,k[%d]=%d,l[%d]=%d\n",i,a[i],i,k[i],i,l[i]);
    
}
   fclose(fp);
    if (argc ==1)
        {
                printf(" On attend en paramètre le nombre de valeurs à traiter.\n");
                exit(2);
        }

        x = atoi(argv[1]);
        y = atoi(argv[2]);
       
polynome(x,y,a,l,k,n);

return 0;
}
