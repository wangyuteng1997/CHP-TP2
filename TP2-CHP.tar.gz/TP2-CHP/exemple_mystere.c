#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

/* Auteur(*) de commentaires : WANG Yuteng */
int maximum(int x, int y)
{
	return (x < y ? y :  x);
}

int main(int argc, char* argv[])
{
    int *a, *b;
    int n, i;
	int taille;

    if (argc ==1)
	{
		printf(" On attend en paramètre le nombre de valeurs à traiter.\n");
		exit(2);
	}

	/* on determine n et on alloue la mémoire pour le tableau */
	n = atoi(argv[1]);
	a = malloc(n * sizeof(int));
	b =  malloc(n * sizeof(int));

	/* Q1 : que fait le code ci-dessus ? */
	/* réponse : here we put the number(11)in the half of the array,and the number
        (10)in the quater of the array,beside all the numbers of the array are 1 

        */
	# pragma omp parralel for
	for(i=0; i < n; i++)
        a[i] = 1;
	
	
	a[n/4] = 10;
	a[n/2] = 11;

	


	/* Q2 : que fait cet algorithme ? 
		reponse : on plie le tableau comme deux partie,et comparer le premiere dans le premiere partie
                et le derniere dans le deuxieme partie et mettre le max de deux number dans le premiere partie
                et le deuxieme.......etc , et faire un loop pour plier et plier enfin il reste un number c'est
                le max number dans le tableau 

 */
	taille = n;
	while (taille > 1){
             if(taille % 2 ==0){
		# pragma omp parallel for
		for (i = 0; i <= taille/2; i++)
	        	{
			b[i] = maximum(a[i], a[taille - 1 - i]);
			a[i] = b[i];
	        	}
		taille = taille/2;
                }

             else
                # pragma omp parallel for
                for (i = 0; i <= taille/2; i++)
                        {
                        b[i] = maximum(a[i], a[taille - 1 - i]);
                        a[i] = b[i];
                        }
                taille = taille/2+1;
                

}
	/* fin Q2*/ 

	/* parfois il se peut que le résultat soit  faux /
	/* Q3 : l'avez vous constaté ?   Oui,par exemple le longeur de tableau est 5,a caused de le
           longeur eet impair,dont 11 dans le position de 1/2 ne peux pas etre compte(c'est a caused de plier)            le resultat est 10 pas 11. 
  */
	/* Même si vous le l'avez pas constater, sachiez qu'il est possible que parfois le résultat soit faux. */
	/* Q4 : Pourquoi une telle afirmation de ma part ? ....... */
	/* Q5 : comment on peut corriger le code ?  
c'est le problem de pair et impair,donc on va juger est-ce que le taille est pair ou impair

*/
 
  	/* Q6 : quelle est la signification de cette valeur ? c'est le maximax nombre dans ce tableau */
	
	printf(" la valeur calculée est : %d\n", a[0]);

}
