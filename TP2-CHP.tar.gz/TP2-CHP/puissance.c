#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>
/* Auteur(*) de commentaires : WANG Yuteng */
float*puissance(float x,int n){

 int i;
 int ecart=1;
 float p[n];
 float q[n];
 q[0]=1;

 # pragma omp parallel for
for(i=1;i<n;i++){
p[i]=x;
p[0]=1;
}

while (ecart <n){
# pragma omp parallel for 
      for (i=1;i<n;i++){
         if(i>ecart){
          q[i]=p[i-ecart]*p[i]; 
           }
           
      }
# pragma omp parallel for 
      for (i=1;i<n;i++){
          p[i]=q[i]; }
 
        ecart = ecart*2;
}

# pragma omp parallel for
for(i=0;i<n;i++){
printf("p[%d] = %f\n",i,p[i]);
    }
     return p;  
}


int main()
{
  int*r;
  int x = 2;
  int n = 5;  
r=malloc(n*sizeof(float));
  int i;
  int t;
 

  
 puissance(x,n);

return 0;
}


